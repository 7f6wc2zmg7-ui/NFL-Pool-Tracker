# Pool Tracker Starter

See ChatGPT instructions for setup.